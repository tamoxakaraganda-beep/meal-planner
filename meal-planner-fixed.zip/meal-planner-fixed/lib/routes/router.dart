// ИСПРАВЛЕНО: import перенесён в начало файла (был в конце — compile error)
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../providers/auth_provider.dart';
import '../screens/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/signup_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/recipes/recipes_screen.dart';
import '../screens/planner/planner_screen.dart';
import '../screens/shopping/shopping_screen.dart';
import '../screens/profile/profile_screen.dart';

final goRouterProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/splash',
    redirect: (context, state) {
      final isLoggedIn = authState.maybeWhen(
        data: (user) => user != null,
        orElse: () => false,
      );
      final isLoading = authState.isLoading;

      // Пока Firebase инициализируется — остаёмся на splash
      if (isLoading) return '/splash';

      final loc = state.matchedLocation;
      final goingToAuth = loc.startsWith('/auth');
      final goingToSplash = loc == '/splash';

      if (!isLoggedIn) {
        return goingToAuth ? null : '/auth/login';
      }

      if (goingToAuth || goingToSplash) return '/home';

      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/auth/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/auth/signup',
        name: 'signup',
        builder: (context, state) => const SignUpScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: '/home',
            name: 'home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: '/recipes',
            name: 'recipes',
            builder: (context, state) => const RecipesScreen(),
          ),
          GoRoute(
            path: '/planner',
            name: 'planner',
            builder: (context, state) => const PlannerScreen(),
          ),
          GoRoute(
            path: '/shopping',
            name: 'shopping',
            builder: (context, state) => const ShoppingScreen(),
          ),
          GoRoute(
            path: '/profile',
            name: 'profile',
            builder: (context, state) => const ProfileScreen(),
          ),
        ],
      ),
    ],
  );
});

/// Нижняя навигация — общая оболочка для всех основных экранов
class MainShell extends StatelessWidget {
  final Widget child;
  const MainShell({Key? key, required this.child}) : super(key: key);

  static const _tabs = [
    ('/home', Icons.home_outlined, Icons.home, 'Главная'),
    ('/recipes', Icons.menu_book_outlined, Icons.menu_book, 'Рецепты'),
    ('/planner', Icons.calendar_month_outlined, Icons.calendar_month, 'План'),
    ('/shopping', Icons.shopping_cart_outlined, Icons.shopping_cart, 'Список'),
    ('/profile', Icons.person_outline, Icons.person, 'Профиль'),
  ];

  int _currentIndex(String location) {
    for (var i = 0; i < _tabs.length; i++) {
      if (location.startsWith(_tabs[i].$1)) return i;
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final index = _currentIndex(location);

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => context.go(_tabs[i].$1),
        destinations: _tabs
            .map((t) => NavigationDestination(
                  icon: Icon(t.$2),
                  selectedIcon: Icon(t.$3),
                  label: t.$4,
                ))
            .toList(),
      ),
    );
  }
}
