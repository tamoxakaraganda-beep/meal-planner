import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' show join;
import '../models/recipe.dart';
import '../models/meal_plan.dart';
import '../models/shopping_item.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static Database? _database;

  factory DatabaseService() {
    return _instance;
  }

  DatabaseService._internal();

  Future<Database> get database async {
    _database ??= await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'meal_planner.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // ИСПРАВЛЕНО: ingredients, instructions, tags хранятся как JSON-строки
    await db.execute('''
      CREATE TABLE IF NOT EXISTS recipes (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        imageUrl TEXT,
        preparationTime INTEGER,
        cookingTime INTEGER,
        servings INTEGER,
        totalCalories REAL,
        rating REAL,
        reviewsCount INTEGER,
        authorId TEXT,
        ingredients TEXT,
        instructions TEXT,
        tags TEXT,
        createdAt TEXT,
        updatedAt TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS meal_plans (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        startDate TEXT,
        endDate TEXT,
        isActive INTEGER,
        meals TEXT,
        createdAt TEXT,
        updatedAt TEXT
      )
    ''');

    // ИСПРАВЛЕНО: таблица shopping_items (не shopping_lists)
    await db.execute('''
      CREATE TABLE IF NOT EXISTS shopping_items (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        quantity REAL,
        unit TEXT,
        category TEXT,
        estimatedPrice REAL,
        isPurchased INTEGER,
        linkedRecipeId TEXT,
        userId TEXT,
        createdAt TEXT,
        updatedAt TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS favorites (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        recipeId TEXT NOT NULL,
        createdAt TEXT
      )
    ''');
  }

  // ── Recipe helpers ──────────────────────────────────────────────────────────

  /// Преобразует Recipe в Map для SQLite (вложенные объекты → JSON-строки)
  Map<String, dynamic> _recipeToRow(Recipe recipe) {
    return {
      'id': recipe.id,
      'title': recipe.title,
      'description': recipe.description,
      'imageUrl': recipe.imageUrl,
      'preparationTime': recipe.preparationTime,
      'cookingTime': recipe.cookingTime,
      'servings': recipe.servings,
      'totalCalories': recipe.totalCalories,
      'rating': recipe.rating,
      'reviewsCount': recipe.reviewsCount,
      'authorId': recipe.authorId,
      'ingredients': jsonEncode(recipe.ingredients.map((i) => i.toJson()).toList()),
      'instructions': jsonEncode(recipe.instructions),
      'tags': jsonEncode(recipe.tags),
      'createdAt': recipe.createdAt.toIso8601String(),
      'updatedAt': recipe.updatedAt.toIso8601String(),
    };
  }

  /// Восстанавливает Recipe из строки SQLite (JSON-строки → объекты)
  Recipe _rowToRecipe(Map<String, dynamic> row) {
    return Recipe.fromJson({
      ...row,
      'ingredients': jsonDecode(row['ingredients'] as String? ?? '[]'),
      'instructions': jsonDecode(row['instructions'] as String? ?? '[]'),
      'tags': jsonDecode(row['tags'] as String? ?? '[]'),
      'createdAt': row['createdAt'],
      'updatedAt': row['updatedAt'],
    });
  }

  Future<void> insertRecipe(Recipe recipe) async {
    final db = await database;
    await db.insert('recipes', _recipeToRow(recipe),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<Recipe?> getRecipe(String id) async {
    final db = await database;
    final result = await db.query('recipes', where: 'id = ?', whereArgs: [id]);
    if (result.isNotEmpty) return _rowToRecipe(result.first);
    return null;
  }

  Future<List<Recipe>> getAllRecipes() async {
    final db = await database;
    final result = await db.query('recipes', orderBy: 'createdAt DESC');
    return result.map(_rowToRecipe).toList();
  }

  Future<List<Recipe>> searchRecipes(String query) async {
    final db = await database;
    final result = await db.query(
      'recipes',
      where: 'title LIKE ? OR tags LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
    );
    return result.map(_rowToRecipe).toList();
  }

  Future<void> updateRecipe(Recipe recipe) async {
    final db = await database;
    await db.update('recipes', _recipeToRow(recipe),
        where: 'id = ?', whereArgs: [recipe.id]);
  }

  Future<void> deleteRecipe(String id) async {
    final db = await database;
    await db.delete('recipes', where: 'id = ?', whereArgs: [id]);
  }

  // ── ShoppingItem helpers ────────────────────────────────────────────────────

  Map<String, dynamic> _shoppingItemToRow(ShoppingItem item, String userId) {
    return {
      'id': item.id,
      'name': item.name,
      'quantity': item.quantity,
      'unit': item.unit,
      'category': item.category.name,
      'estimatedPrice': item.estimatedPrice,
      'isPurchased': item.isPurchased ? 1 : 0,
      'linkedRecipeId': item.linkedRecipeId,
      'userId': userId,
      'createdAt': item.createdAt.toIso8601String(),
      'updatedAt': item.updatedAt.toIso8601String(),
    };
  }

  ShoppingItem _rowToShoppingItem(Map<String, dynamic> row) {
    return ShoppingItem.fromJson({
      ...row,
      'isPurchased': row['isPurchased'] == 1,
      'category': row['category'],
    });
  }

  Future<void> insertShoppingItem(ShoppingItem item, String userId) async {
    final db = await database;
    await db.insert('shopping_items', _shoppingItemToRow(item, userId),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ShoppingItem>> getShoppingItems(String userId) async {
    final db = await database;
    final result = await db.query(
      'shopping_items',
      where: 'userId = ?',
      whereArgs: [userId],
      orderBy: 'createdAt DESC',
    );
    return result.map(_rowToShoppingItem).toList();
  }

  Future<void> updateShoppingItem(ShoppingItem item, String userId) async {
    final db = await database;
    await db.update('shopping_items', _shoppingItemToRow(item, userId),
        where: 'id = ?', whereArgs: [item.id]);
  }

  Future<void> deleteShoppingItem(String id) async {
    final db = await database;
    await db.delete('shopping_items', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clearPurchasedItems(String userId) async {
    final db = await database;
    await db.delete('shopping_items',
        where: 'userId = ? AND isPurchased = 1', whereArgs: [userId]);
  }

  // ── Favorites helpers ───────────────────────────────────────────────────────

  Future<void> addToFavorites(String userId, String recipeId) async {
    final db = await database;
    await db.insert(
      'favorites',
      {
        'id': '${userId}_$recipeId',
        'userId': userId,
        'recipeId': recipeId,
        'createdAt': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> removeFromFavorites(String userId, String recipeId) async {
    final db = await database;
    await db.delete(
      'favorites',
      where: 'userId = ? AND recipeId = ?',
      whereArgs: [userId, recipeId],
    );
  }

  Future<List<String>> getFavoriteRecipeIds(String userId) async {
    final db = await database;
    final result = await db.query(
      'favorites',
      columns: ['recipeId'],
      where: 'userId = ?',
      whereArgs: [userId],
    );
    return result.map((e) => e['recipeId'] as String).toList();
  }

  Future<void> closeDatabase() async {
    final db = await database;
    await db.close();
    _database = null;
  }
}
