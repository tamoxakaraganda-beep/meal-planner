import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/recipe_provider.dart';
import '../../theme/colors.dart';
import '../../widgets/recipe_card.dart';

class RecipesScreen extends ConsumerWidget {
  const RecipesScreen({Key? key}) : super(key: key);

  static const _allTags = [
    'вегетарианское',
    'веганское',
    'без глютена',
    'low-carb',
    'завтрак',
    'обед',
    'ужин',
    'быстрое',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filteredAsync = ref.watch(filteredRecipesProvider);
    final searchQuery = ref.watch(recipeSearchProvider);
    final selectedTags = ref.watch(selectedTagsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Рецепты'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Поиск рецептов...',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
              onChanged: (v) =>
                  ref.read(recipeSearchProvider.notifier).state = v,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Фильтры по тегам
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              children: _allTags.map((tag) {
                final selected = selectedTags.contains(tag);
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(tag),
                    selected: selected,
                    onSelected: (v) {
                      final tags =
                          List<String>.from(ref.read(selectedTagsProvider));
                      if (v) {
                        tags.add(tag);
                      } else {
                        tags.remove(tag);
                      }
                      ref.read(selectedTagsProvider.notifier).state = tags;
                    },
                  ),
                );
              }).toList(),
            ),
          ),

          // Список рецептов
          Expanded(
            child: filteredAsync.when(
              loading: () =>
                  const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline,
                        size: 48, color: AppColors.error),
                    const SizedBox(height: 12),
                    Text('Ошибка загрузки: $e'),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () => ref.invalidate(recipesProvider),
                      child: const Text('Повторить'),
                    ),
                  ],
                ),
              ),
              data: (recipes) {
                if (recipes.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.search_off,
                            size: 64, color: AppColors.grey),
                        const SizedBox(height: 12),
                        Text(
                          searchQuery.isNotEmpty
                              ? 'Рецепты не найдены'
                              : 'Рецептов пока нет',
                          style: const TextStyle(color: AppColors.grey),
                        ),
                      ],
                    ),
                  );
                }
                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.72,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: recipes.length,
                  itemBuilder: (context, index) {
                    final recipe = recipes[index];
                    final isFav = ref
                        .watch(favoriteRecipesProvider)
                        .contains(recipe.id);
                    return RecipeCard(
                      recipe: recipe,
                      isFavorite: isFav,
                      onTap: () {},
                      onFavoriteTap: () => ref
                          .read(favoriteRecipesProvider.notifier)
                          .toggle(recipe.id),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
