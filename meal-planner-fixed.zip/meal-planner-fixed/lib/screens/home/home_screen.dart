import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/meal_plan_provider.dart';
import '../../theme/colors.dart';
import '../../models/meal_plan.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final today = DateTime.now();
    final meals = ref.watch(mealsForDateProvider(today));
    final totalCalories = ref.watch(totalCaloriesForDateProvider(today));

    final greeting = _greeting();
    final name = user?.displayName ?? user?.email?.split('@').first ?? 'пользователь';

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(greeting,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: AppColors.grey)),
            Text(name, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Дата
            Text(
              DateFormat('EEEE, d MMMM', 'ru').format(today),
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // Карточка калорий
            _CaloriesSummaryCard(
              totalCalories: totalCalories,
              mealsCount: meals.length,
            ),
            const SizedBox(height: 20),

            // Быстрые действия
            Text('Быстрые действия',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Row(
              children: [
                _QuickActionCard(
                  icon: Icons.search,
                  label: 'Найти рецепт',
                  color: AppColors.primary,
                  onTap: () => context.go('/recipes'),
                ),
                const SizedBox(width: 12),
                _QuickActionCard(
                  icon: Icons.calendar_today,
                  label: 'Мой план',
                  color: AppColors.accent,
                  onTap: () => context.go('/planner'),
                ),
                const SizedBox(width: 12),
                _QuickActionCard(
                  icon: Icons.shopping_cart,
                  label: 'Список',
                  color: AppColors.secondary,
                  onTap: () => context.go('/shopping'),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Приёмы пищи сегодня
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Сегодня',
                    style: Theme.of(context).textTheme.titleMedium),
                TextButton(
                  onPressed: () => context.go('/planner'),
                  child: const Text('Все'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (meals.isEmpty)
              _EmptyMealsCard(onAddTap: () => context.go('/planner'))
            else
              ...meals.map((meal) => _MealSummaryTile(meal: meal)),
          ],
        ),
      ),
    );
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Доброе утро,';
    if (hour < 17) return 'Добрый день,';
    return 'Добрый вечер,';
  }
}

class _CaloriesSummaryCard extends StatelessWidget {
  final double totalCalories;
  final int mealsCount;

  const _CaloriesSummaryCard(
      {required this.totalCalories, required this.mealsCount});

  @override
  Widget build(BuildContext context) {
    const goal = 2000.0;
    final progress = (totalCalories / goal).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppGradients.primaryGradient,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${totalCalories.toStringAsFixed(0)} ккал',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold),
              ),
              Text(
                'цель: ${goal.toStringAsFixed(0)}',
                style: TextStyle(color: Colors.white.withOpacity(0.8)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.white.withOpacity(0.3),
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              minHeight: 8,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '$mealsCount ${_mealWord(mealsCount)} сегодня',
            style: TextStyle(color: Colors.white.withOpacity(0.9)),
          ),
        ],
      ),
    );
  }

  String _mealWord(int count) {
    if (count == 1) return 'приём пищи';
    if (count < 5) return 'приёма пищи';
    return 'приёмов пищи';
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionCard(
      {required this.icon,
      required this.label,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 6),
              Text(label,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MealSummaryTile extends StatelessWidget {
  final Meal meal;
  const _MealSummaryTile({required this.meal});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppColors.primary.withOpacity(0.1),
          child: Icon(_mealIcon(meal.mealType), color: AppColors.primary),
        ),
        title: Text(meal.recipe.title),
        subtitle: Text(_mealTypeLabel(meal.mealType)),
        trailing: Text('${meal.totalCalories.toStringAsFixed(0)} ккал',
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(color: AppColors.primary, fontWeight: FontWeight.w600)),
      ),
    );
  }

  IconData _mealIcon(MealType type) {
    switch (type) {
      case MealType.breakfast:
        return Icons.wb_sunny_outlined;
      case MealType.lunch:
        return Icons.lunch_dining_outlined;
      case MealType.dinner:
        return Icons.dinner_dining_outlined;
      case MealType.snack:
        return Icons.cookie_outlined;
    }
  }

  String _mealTypeLabel(MealType type) {
    switch (type) {
      case MealType.breakfast:
        return 'Завтрак';
      case MealType.lunch:
        return 'Обед';
      case MealType.dinner:
        return 'Ужин';
      case MealType.snack:
        return 'Перекус';
    }
  }
}

class _EmptyMealsCard extends StatelessWidget {
  final VoidCallback onAddTap;
  const _EmptyMealsCard({required this.onAddTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Icon(Icons.no_meals_outlined,
                size: 48, color: AppColors.grey),
            const SizedBox(height: 12),
            Text('На сегодня ничего не запланировано',
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: AppColors.grey)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onAddTap,
              icon: const Icon(Icons.add),
              label: const Text('Добавить приём пищи'),
            ),
          ],
        ),
      ),
    );
  }
}
