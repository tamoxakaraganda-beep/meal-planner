import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/shopping_provider.dart';
import '../../theme/colors.dart';
import '../../models/shopping_item.dart';
import '../../widgets/shopping_list_item.dart';

class ShoppingScreen extends ConsumerWidget {
  const ShoppingScreen({Key? key}) : super(key: key);

  static const _categoryLabels = {
    ItemCategory.produce: 'Овощи и фрукты',
    ItemCategory.dairy: 'Молочные продукты',
    ItemCategory.meat: 'Мясо и рыба',
    ItemCategory.pantry: 'Бакалея',
    ItemCategory.frozen: 'Заморозка',
    ItemCategory.beverages: 'Напитки',
    ItemCategory.other: 'Прочее',
  };

  static const _categoryIcons = {
    ItemCategory.produce: Icons.eco_outlined,
    ItemCategory.dairy: Icons.water_drop_outlined,
    ItemCategory.meat: Icons.set_meal_outlined,
    ItemCategory.pantry: Icons.kitchen_outlined,
    ItemCategory.frozen: Icons.ac_unit_outlined,
    ItemCategory.beverages: Icons.local_drink_outlined,
    ItemCategory.other: Icons.category_outlined,
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final itemsByCategory = ref.watch(itemsByCategoryProvider);
    final unpurchased = ref.watch(unpurchasedItemsProvider);
    final totalPrice = ref.watch(totalPriceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Список покупок'),
        actions: [
          if (ref.watch(purchasedItemsProvider).isNotEmpty)
            TextButton(
              onPressed: () =>
                  ref.read(shoppingItemsProvider.notifier).clearPurchased(),
              child: const Text('Очистить'),
            ),
        ],
      ),
      body: Column(
        children: [
          // Сводка
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _SummaryItem(
                  label: 'Осталось',
                  value: '${unpurchased.length}',
                  icon: Icons.shopping_basket_outlined,
                ),
                Container(width: 1, height: 40, color: AppColors.greyLight),
                _SummaryItem(
                  label: 'Итого',
                  value: '${totalPrice.toStringAsFixed(0)} ₽',
                  icon: Icons.payments_outlined,
                ),
              ],
            ),
          ),

          // Список по категориям
          Expanded(
            child: itemsByCategory.isEmpty
                ? const _EmptyShoppingList()
                : ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: ItemCategory.values
                        .where((cat) => itemsByCategory.containsKey(cat))
                        .map((cat) {
                      final items = itemsByCategory[cat]!;
                      return _CategorySection(
                        categoryLabel: _categoryLabels[cat] ?? cat.name,
                        categoryIcon:
                            _categoryIcons[cat] ?? Icons.category_outlined,
                        items: items,
                        ref: ref,
                      );
                    }).toList(),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddItemDialog(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Добавить'),
      ),
    );
  }

  void _showAddItemDialog(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _AddItemSheet(ref: ref),
    );
  }
}

class _CategorySection extends StatelessWidget {
  final String categoryLabel;
  final IconData categoryIcon;
  final List<ShoppingItem> items;
  final WidgetRef ref;

  const _CategorySection({
    required this.categoryLabel,
    required this.categoryIcon,
    required this.items,
    required this.ref,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12, bottom: 4),
          child: Row(
            children: [
              Icon(categoryIcon, size: 18, color: AppColors.grey),
              const SizedBox(width: 6),
              Text(categoryLabel,
                  style: Theme.of(context)
                      .textTheme
                      .labelLarge
                      ?.copyWith(color: AppColors.grey)),
            ],
          ),
        ),
        ...items.map((item) => ShoppingListItemWidget(
              item: item,
              onPurchasedChanged: (_) => ref
                  .read(shoppingItemsProvider.notifier)
                  .toggleItemPurchased(item.id),
              onDelete: () => ref
                  .read(shoppingItemsProvider.notifier)
                  .removeItem(item.id),
            )),
      ],
    );
  }
}

class _SummaryItem extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _SummaryItem(
      {required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: AppColors.primary),
        const SizedBox(height: 4),
        Text(value,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold)),
        Text(label,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(color: AppColors.grey)),
      ],
    );
  }
}

class _EmptyShoppingList extends StatelessWidget {
  const _EmptyShoppingList();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.shopping_cart_outlined,
              size: 64, color: AppColors.grey),
          const SizedBox(height: 12),
          Text('Список покупок пуст',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(color: AppColors.grey)),
          const SizedBox(height: 8),
          const Text('Добавьте продукты или сформируйте список\nиз плана питания',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.grey)),
        ],
      ),
    );
  }
}

class _AddItemSheet extends ConsumerStatefulWidget {
  final WidgetRef ref;
  const _AddItemSheet({required this.ref});

  @override
  ConsumerState<_AddItemSheet> createState() => _AddItemSheetState();
}

class _AddItemSheetState extends ConsumerState<_AddItemSheet> {
  final _nameController = TextEditingController();
  final _quantityController = TextEditingController();
  final _unitController = TextEditingController(text: 'шт');
  ItemCategory _selectedCategory = ItemCategory.other;

  @override
  void dispose() {
    _nameController.dispose();
    _quantityController.dispose();
    _unitController.dispose();
    super.dispose();
  }

  void _addItem() {
    if (_nameController.text.isEmpty) return;

    final now = DateTime.now();
    final item = ShoppingItem(
      id: '${now.millisecondsSinceEpoch}',
      name: _nameController.text.trim(),
      quantity: double.tryParse(_quantityController.text) ?? 1,
      unit: _unitController.text.trim(),
      category: _selectedCategory,
      isPurchased: false,
      createdAt: now,
      updatedAt: now,
    );

    ref.read(shoppingItemsProvider.notifier).addItem(item);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Добавить продукт',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          TextField(
            controller: _nameController,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Название'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Количество'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _unitController,
                  decoration: const InputDecoration(labelText: 'Единица'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<ItemCategory>(
            value: _selectedCategory,
            decoration: const InputDecoration(labelText: 'Категория'),
            items: ItemCategory.values.map((cat) {
              const labels = {
                ItemCategory.produce: 'Овощи и фрукты',
                ItemCategory.dairy: 'Молочные продукты',
                ItemCategory.meat: 'Мясо и рыба',
                ItemCategory.pantry: 'Бакалея',
                ItemCategory.frozen: 'Заморозка',
                ItemCategory.beverages: 'Напитки',
                ItemCategory.other: 'Прочее',
              };
              return DropdownMenuItem(
                value: cat,
                child: Text(labels[cat] ?? cat.name),
              );
            }).toList(),
            onChanged: (v) => setState(() => _selectedCategory = v!),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _addItem,
            child: const Text('Добавить'),
          ),
        ],
      ),
    );
  }
}
