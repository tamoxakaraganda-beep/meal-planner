import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/auth_provider.dart';
import '../../theme/colors.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Профиль')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Аватар и имя
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              color: AppColors.primary.withOpacity(0.05),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 48,
                    backgroundColor: AppColors.primary,
                    child: Text(
                      (user?.displayName?.isNotEmpty == true
                              ? user!.displayName![0]
                              : user?.email?[0] ?? '?')
                          .toUpperCase(),
                      style: const TextStyle(
                          fontSize: 36,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    user?.displayName ?? 'Пользователь',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user?.email ?? '',
                    style: const TextStyle(color: AppColors.grey),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Настройки
            _SettingsSection(title: 'Аккаунт', tiles: [
              _SettingsTile(
                icon: Icons.person_outline,
                label: 'Редактировать профиль',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.lock_outline,
                label: 'Сменить пароль',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.notifications_outlined,
                label: 'Уведомления',
                onTap: () {},
              ),
            ]),

            _SettingsSection(title: 'Питание', tiles: [
              _SettingsTile(
                icon: Icons.flag_outlined,
                label: 'Цель по калориям',
                trailing: const Text('2000 ккал',
                    style: TextStyle(color: AppColors.grey)),
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.restaurant_menu_outlined,
                label: 'Диетические предпочтения',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.warning_amber_outlined,
                label: 'Аллергии',
                onTap: () {},
              ),
            ]),

            _SettingsSection(title: 'Приложение', tiles: [
              _SettingsTile(
                icon: Icons.color_lens_outlined,
                label: 'Тема оформления',
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.language_outlined,
                label: 'Язык',
                trailing: const Text('Русский',
                    style: TextStyle(color: AppColors.grey)),
                onTap: () {},
              ),
              _SettingsTile(
                icon: Icons.help_outline,
                label: 'Поддержка',
                onTap: () {},
              ),
            ]),

            const SizedBox(height: 8),

            Padding(
              padding: const EdgeInsets.all(16),
              child: OutlinedButton.icon(
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Выход'),
                      content:
                          const Text('Вы уверены, что хотите выйти из аккаунта?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('Отмена'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Выйти',
                              style: TextStyle(color: AppColors.error)),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await ref.read(signOutProvider.future);
                  }
                },
                icon: const Icon(Icons.logout, color: AppColors.error),
                label: const Text('Выйти из аккаунта',
                    style: TextStyle(color: AppColors.error)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.error),
                  minimumSize: const Size(double.infinity, 48),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  final String title;
  final List<_SettingsTile> tiles;

  const _SettingsSection({required this.title, required this.tiles});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(
            title,
            style: Theme.of(context)
                .textTheme
                .labelLarge
                ?.copyWith(color: AppColors.grey),
          ),
        ),
        Card(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: tiles
                .map((t) => ListTile(
                      leading: Icon(t.icon, color: AppColors.primary),
                      title: Text(t.label),
                      trailing: t.trailing ??
                          const Icon(Icons.chevron_right, color: AppColors.grey),
                      onTap: t.onTap,
                    ))
                .toList(),
          ),
        ),
      ],
    );
  }
}

class _SettingsTile {
  final IconData icon;
  final String label;
  final Widget? trailing;
  final VoidCallback onTap;

  const _SettingsTile(
      {required this.icon,
      required this.label,
      this.trailing,
      required this.onTap});
}
