import 'package:flutter/material.dart';
import '../models/shopping_item.dart';
import '../theme/colors.dart';

class ShoppingListItemWidget extends StatelessWidget {
  final ShoppingItem item;
  final ValueChanged<bool> onPurchasedChanged;
  final VoidCallback? onDelete;
  final VoidCallback? onEdit;

  const ShoppingListItemWidget({
    Key? key,
    required this.item,
    required this.onPurchasedChanged,
    this.onDelete,
    this.onEdit,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: Row(
          children: [
            Checkbox(
              value: item.isPurchased,
              onChanged: (value) => onPurchasedChanged(value ?? false),
              activeColor: AppColors.primary,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          decoration: item.isPurchased
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                          color: item.isPurchased ? AppColors.grey : null,
                        ),
                  ),
                  Text(
                    '${item.quantity} ${item.unit}',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: AppColors.grey),
                  ),
                ],
              ),
            ),
            if (item.estimatedPrice != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  '${item.estimatedPrice!.toStringAsFixed(2)} ₽',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            // ИСПРАВЛЕНО: PopupMenuItem.onTap вызывался до закрытия меню,
            // что приводило к ошибке setState during build.
            // Используем PopupMenuButton.onSelected вместо onTap у item.
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') onEdit?.call();
                if (value == 'delete') onDelete?.call();
              },
              itemBuilder: (context) => [
                if (onEdit != null)
                  const PopupMenuItem(
                    value: 'edit',
                    child: Text('Редактировать'),
                  ),
                if (onDelete != null)
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline, color: AppColors.error, size: 18),
                        SizedBox(width: 8),
                        Text('Удалить', style: TextStyle(color: AppColors.error)),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
