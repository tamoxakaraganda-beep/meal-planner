import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/recipe.dart';
import '../services/database_service.dart';

final databaseServiceProvider = Provider((ref) => DatabaseService());

final recipesProvider = FutureProvider<List<Recipe>>((ref) async {
  final dbService = ref.watch(databaseServiceProvider);
  return dbService.getAllRecipes();
});

final recipeProvider =
    FutureProvider.family<Recipe?, String>((ref, recipeId) async {
  final dbService = ref.watch(databaseServiceProvider);
  return dbService.getRecipe(recipeId);
});

final favoriteRecipesProvider =
    StateNotifierProvider<FavoriteRecipesNotifier, List<String>>(
  (ref) => FavoriteRecipesNotifier(ref),
);

class FavoriteRecipesNotifier extends StateNotifier<List<String>> {
  final Ref ref;

  FavoriteRecipesNotifier(this.ref) : super([]);

  void addFavorite(String recipeId) {
    if (!state.contains(recipeId)) {
      state = [...state, recipeId];
    }
  }

  void removeFavorite(String recipeId) {
    state = state.where((id) => id != recipeId).toList();
  }

  bool isFavorite(String recipeId) => state.contains(recipeId);

  void toggle(String recipeId) {
    if (isFavorite(recipeId)) {
      removeFavorite(recipeId);
    } else {
      addFavorite(recipeId);
    }
  }
}

final recipeSearchProvider = StateProvider<String>((ref) => '');

final selectedTagsProvider = StateProvider<List<String>>((ref) => []);

// ИСПРАВЛЕНО: правильная обработка AsyncValue из FutureProvider
final filteredRecipesProvider = Provider<AsyncValue<List<Recipe>>>((ref) {
  final recipesAsync = ref.watch(recipesProvider);
  final searchQuery = ref.watch(recipeSearchProvider).trim().toLowerCase();
  final selectedTags = ref.watch(selectedTagsProvider);

  return recipesAsync.whenData((recipes) {
    var result = recipes;

    if (searchQuery.isNotEmpty) {
      result = result
          .where((r) =>
              r.title.toLowerCase().contains(searchQuery) ||
              r.description.toLowerCase().contains(searchQuery) ||
              r.tags.any((t) => t.toLowerCase().contains(searchQuery)))
          .toList();
    }

    if (selectedTags.isNotEmpty) {
      result = result
          .where((r) => selectedTags.every((tag) => r.tags.contains(tag)))
          .toList();
    }

    return result;
  });
});
